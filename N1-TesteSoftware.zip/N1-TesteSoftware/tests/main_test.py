import pytest
from main import cesar


def test_cesar():
    assert cesar('Arroz', 3, 0) #descript

def test_cesar2():
    assert cesar('Arroz', 3, 1) #cript